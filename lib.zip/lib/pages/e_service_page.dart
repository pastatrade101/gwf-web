import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import 'e_service_detail_page.dart';


class EServicesPage extends StatelessWidget {
  EServicesPage({super.key});

  final EServicesController c = Get.put(EServicesController(), permanent: false);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_rounded, color: AppColors.text),
          onPressed: () => Navigator.maybePop(context),
        ),
        title: Text(
          "Government E-Services",
          style: AppTextStyles.appBar,
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications_none_rounded, color: AppColors.text),
            onPressed: () {},
          ),
        ],
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
              child: _SearchBar(
                onChanged: c.onSearchChanged,
                hint: "Search for a service...",
              ),
            ),

            // Category chips
            SizedBox(
              height: 44,
              child: Obx(() {
                final cats = c.categories;
                return ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  scrollDirection: Axis.horizontal,
                  itemCount: cats.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, i) {
                    final label = cats[i];
                    final selected = c.activeCategory.value == label;

                    return ChoiceChip(
                      label: Text(label),
                      selected: selected,
                      showCheckmark: false,
                      labelStyle: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: selected ? Colors.white : AppColors.text,
                      ),
                      selectedColor: AppColors.secondary,
                      backgroundColor: Colors.white,
                      shape: StadiumBorder(
                        side: BorderSide(
                          color: selected ? Colors.transparent : AppColors.border,
                        ),
                      ),
                      onSelected: (_) => c.activeCategory.value = label,
                    );
                  },
                );
              }),
            ),

            const SizedBox(height: 10),

            // Info banner
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.accent.withOpacity(0.18)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline_rounded, color: AppColors.accent, size: 18),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        "Information only. No login required.",
                        style: AppTextStyles.bodyMuted,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Expanded(
              child: Obx(() {
                if (c.isLoading.value) {
                  return const _LoadingList();
                }

                if (c.error.value != null) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Text(
                        "Failed to load services:\n${c.error.value}",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.error, fontWeight: FontWeight.w700),
                      ),
                    ),
                  );
                }

                final list = c.filtered;
                if (list.isEmpty) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Text(
                        "No services found.",
                        style: AppTextStyles.bodyMuted,
                      ),
                    ),
                  );
                }

                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(18, 6, 18, 18),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) => _ServiceCard(
                    item: list[i],
                    onTap: () => Get.to(() => EServiceDetailPage(service: list[i])),
                  ),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}

/* ----------------------------- Controller ----------------------------- */

class EServicesController extends GetxController {
  final _db = FirebaseFirestore.instance;
  StreamSubscription? _sub;

  // state
  final isLoading = true.obs;
  final RxnString error = RxnString();

  final all = <EServiceModel>[].obs;

  // filters
  final activeCategory = "All".obs;
  final query = "".obs;

  late final Worker _debouncer;

  List<String> get categories {
    final set = <String>{"All"};
    for (final s in all) {
      if (s.category.trim().isNotEmpty) set.add(s.category.trim());
    }
    return set.toList();
  }

  List<EServiceModel> get filtered {
    final q = query.value.trim().toLowerCase();
    final cat = activeCategory.value;

    final list = all.where((s) {
      final catOk = (cat == "All") || s.category == cat;
      final qOk = q.isEmpty ||
          s.title.toLowerCase().contains(q) ||
          s.subtitle.toLowerCase().contains(q) ||
          s.ministry.toLowerCase().contains(q) ||
          s.category.toLowerCase().contains(q);
      return catOk && qOk;
    }).toList();

    list.sort((a, b) => b.priority.compareTo(a.priority));
    return list;
  }

  @override
  void onInit() {
    super.onInit();

    // debounce search updates (prevents rebuild spam while typing)
    _debouncer = debounce<String>(
      query,
          (_) {}, // we only store query; UI reads filtered reactively
      time: const Duration(milliseconds: 350),
    );

    _sub = _db
        .collection("e_services") // ✅ your portal should write here
        .where("isActive", isEqualTo: true)
        .snapshots()
        .listen((snap) {
      final list = snap.docs
          .map((d) => EServiceModel.fromMap(d.data(), id: d.id))
          .toList();

      all.assignAll(list);
      isLoading.value = false;
      error.value = null;
    }, onError: (e) {
      isLoading.value = false;
      error.value = e.toString();
    });
  }

  void onSearchChanged(String v) {
    query.value = v.trim();
  }

  @override
  void onClose() {
    _sub?.cancel();
    _debouncer.dispose();
    super.onClose();
  }
}

/* ----------------------------- Model ----------------------------- */

class EServiceModel {
  final String id;
  final String title;
  final String subtitle;
  final String category;
  final String ministry;

  final String logoUrl; // small icon
  final String heroUrl; // optional banner/hero image

  final String portalUrl;
  final bool isActive;
  final int priority;

  final DateTime? updatedAt;

  // detail fields
  final String overview;
  final List<String> eligibility;
  final List<DocItem> requiredDocs;
  final List<StepItem> processSteps;
  final List<FaqItem> faqs;

  final int etaMinutes;

  const EServiceModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.category,
    required this.ministry,
    required this.logoUrl,
    required this.heroUrl,
    required this.portalUrl,
    required this.isActive,
    required this.priority,
    required this.updatedAt,
    required this.overview,
    required this.eligibility,
    required this.requiredDocs,
    required this.processSteps,
    required this.faqs,
    required this.etaMinutes,
  });

  factory EServiceModel.fromMap(Map<String, dynamic> data, {required String id}) {
    String s(dynamic v, {String fallback = ""}) {
      if (v == null) return fallback;
      if (v is String) return v.trim();
      return v.toString().trim();
    }

    int i(dynamic v, {int fallback = 0}) {
      if (v == null) return fallback;
      if (v is int) return v;
      if (v is double) return v.toInt();
      if (v is String) return int.tryParse(v) ?? fallback;
      return fallback;
    }

    bool b(dynamic v, {bool fallback = false}) {
      if (v == null) return fallback;
      if (v is bool) return v;
      if (v is num) return v != 0;
      if (v is String) {
        final x = v.toLowerCase().trim();
        if (x == "true" || x == "1" || x == "yes") return true;
        if (x == "false" || x == "0" || x == "no") return false;
      }
      return fallback;
    }

    DateTime? dt(dynamic v) {
      if (v == null) return null;
      if (v is DateTime) return v;
      try {
        final dynamic dyn = v;
        final d = dyn.toDate?.call();
        if (d is DateTime) return d;
      } catch (_) {}
      if (v is int) return DateTime.fromMillisecondsSinceEpoch(v);
      if (v is String) return DateTime.tryParse(v);
      return null;
    }

    List<String> listStr(dynamic v) {
      if (v is List) {
        return v.map((e) => s(e)).where((x) => x.isNotEmpty).toList();
      }
      return const [];
    }

    List<DocItem> listDocs(dynamic v) {
      if (v is List) {
        return v
            .whereType<Map>()
            .map((m) => DocItem.fromMap(Map<String, dynamic>.from(m)))
            .toList();
      }
      return const [];
    }

    List<StepItem> listSteps(dynamic v) {
      if (v is List) {
        return v
            .whereType<Map>()
            .map((m) => StepItem.fromMap(Map<String, dynamic>.from(m)))
            .toList();
      }
      return const [];
    }

    List<FaqItem> listFaq(dynamic v) {
      if (v is List) {
        return v
            .whereType<Map>()
            .map((m) => FaqItem.fromMap(Map<String, dynamic>.from(m)))
            .toList();
      }
      return const [];
    }

    return EServiceModel(
      id: id,
      title: s(data["title"], fallback: "Untitled Service"),
      subtitle: s(data["subtitle"], fallback: ""),
      category: s(data["category"], fallback: "All"),
      ministry: s(data["ministry"], fallback: ""),
      logoUrl: s(data["logoUrl"] ?? data["logo"] ?? data["imageUrl"], fallback: ""),
      heroUrl: s(data["heroUrl"] ?? data["bannerUrl"], fallback: ""),
      portalUrl: s(data["portalUrl"] ?? data["link"], fallback: ""),
      isActive: b(data["isActive"], fallback: true),
      priority: i(data["priority"], fallback: 0),
      updatedAt: dt(data["updatedAt"] ?? data["createdAt"]),
      overview: s(data["overview"], fallback: s(data["description"], fallback: "")),
      eligibility: listStr(data["eligibility"]),
      requiredDocs: listDocs(data["requiredDocs"]),
      processSteps: listSteps(data["processSteps"]),
      faqs: listFaq(data["faqs"]),
      etaMinutes: i(data["etaMinutes"], fallback: 10),
    );
  }
}

class DocItem {
  final String title;
  final String type; // e.g. PDF, JPG
  final String icon; // optional future use

  const DocItem({required this.title, required this.type, required this.icon});

  factory DocItem.fromMap(Map<String, dynamic> m) {
    final t = (m["title"] ?? "").toString().trim();
    final ty = (m["type"] ?? "").toString().trim();
    final ic = (m["icon"] ?? "").toString().trim();
    return DocItem(title: t, type: ty, icon: ic);
  }
}

class StepItem {
  final String title;
  final String description;

  const StepItem({required this.title, required this.description});

  factory StepItem.fromMap(Map<String, dynamic> m) {
    return StepItem(
      title: (m["title"] ?? "").toString().trim(),
      description: (m["description"] ?? "").toString().trim(),
    );
  }
}

class FaqItem {
  final String q;
  final String a;

  const FaqItem({required this.q, required this.a});

  factory FaqItem.fromMap(Map<String, dynamic> m) {
    return FaqItem(
      q: (m["q"] ?? m["question"] ?? "").toString().trim(),
      a: (m["a"] ?? m["answer"] ?? "").toString().trim(),
    );
  }
}

/* ----------------------------- Widgets ----------------------------- */

class _SearchBar extends StatelessWidget {
  const _SearchBar({required this.onChanged, required this.hint});

  final ValueChanged<String> onChanged;
  final String hint;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: TextField(
        onChanged: onChanged,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: AppColors.textMuted),
          prefixIcon: Icon(Icons.search_rounded, color: AppColors.textMuted),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }
}

class _ServiceCard extends StatelessWidget {
  const _ServiceCard({required this.item, required this.onTap});

  final EServiceModel item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.card,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              _NetImage(
                url: item.logoUrl,
                size: 48,
                radius: 14,
                fallbackIcon: Icons.apps_rounded,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.sectionTitle),
                    const SizedBox(height: 4),
                    Text(
                      item.subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.bodyMuted,
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        _Tag(item.category),
                        const Spacer(),
                        Text("Learn More →", style: AppTextStyles.link),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(0.10),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontWeight: FontWeight.w800,
          fontSize: 12,
          color: AppColors.accent,
        ),
      ),
    );
  }
}

class _LoadingList extends StatelessWidget {
  const _LoadingList();

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 18),
      itemCount: 6,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, __) => Container(
        height: 96,
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
        ),
      ),
    );
  }
}

class _NetImage extends StatelessWidget {
  const _NetImage({
    required this.url,
    required this.size,
    required this.radius,
    required this.fallbackIcon,
  });

  final String url;
  final double size;
  final double radius;
  final IconData fallbackIcon;

  bool get _has => url.trim().isNotEmpty;

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(0.10),
        borderRadius: BorderRadius.circular(radius),
      ),
      child: Icon(fallbackIcon, color: AppColors.accent),
    );

    if (!_has) return fallback;

    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Image.network(
        url.trim(),
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => fallback,
      ),
    );
  }
}