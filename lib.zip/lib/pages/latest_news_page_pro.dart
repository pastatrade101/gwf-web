import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/news_controller.dart';
import '../core/constants/app_text_styles.dart';
import '../widgets/news_widgets.dart';
import 'news_detail.dart';

class LatestNewsPagePro extends StatefulWidget {
  const LatestNewsPagePro({super.key});

  @override
  State<LatestNewsPagePro> createState() => _LatestNewsPageProState();
}

class _LatestNewsPageProState extends State<LatestNewsPagePro> {
  late final NewsController c;
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    c = Get.put(NewsController(), permanent: true); // ✅ put once
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB),
      body: SafeArea(
        child: Obx(() {
          // ✅ MUST read Rx values inside Obx
          final isLoading = c.loading.value;
          final err = c.error.value;

          if (isLoading) return const NewsShimmer();
          if (err.isNotEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text("Failed to load news:\n$err", textAlign: TextAlign.center),
              ),
            );
          }

          final featured = c.featured; // depends on Rx internally
          final recent = c.recent;     // depends on Rx internally

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 6, 18, 18),
            children: [
              Text(
                "Latest News",
                style: AppTextStyles.link,

              ),
              const SizedBox(height: 14),

              NewsSearchBox(
                controller: _searchCtrl,
                onChanged: c.onSearchChanged, // debounced
              ),
              const SizedBox(height: 16),

              SizedBox(
                height: 44,
                child: Obx(() {
                  final active = c.activeTab.value; // ✅ Rx used here
                  return ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: c.tabs.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, i) {
                      final isActive = i == active;
                      return ChoiceChip(
                        label: Text(c.tabs[i]),
                        selected: isActive,
                        showCheckmark: false,
                        onSelected: (_) => c.setTab(i),
                      );
                    },
                  );
                }),
              ),
              const SizedBox(height: 16),

              if (featured != null) ...[
                FeaturedCard(
                  item: featured,
                  onReadFull: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => NewsDetailPagePro(news: featured)),
                    );
                  },
                ),
                const SizedBox(height: 18),
              ],

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Recent Updates",
                      style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                  TextButton(onPressed: () {}, child: const Text("View Archive")),
                ],
              ),
              const SizedBox(height: 10),

              if (recent.isEmpty)
                Center(
                  child: Obx(() {
                    final tab = c.selectedTab; // ✅ reads activeTab.value internally
                    return Text('No updates found for "$tab".');
                  }),
                )
              else
                ...recent.map((item) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: RecentTile(
                      item: item,
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => NewsDetailPagePro(news: item)),
                        );
                      },
                    ),
                  );
                }),
            ],
          );
        }),
      ),
    );
  }
}