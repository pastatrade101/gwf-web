import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import 'e_service_page.dart';


class EServiceDetailPage extends StatelessWidget {
  const EServiceDetailPage({super.key, required this.service});

  final EServiceModel service;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColors.bg,
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              backgroundColor: AppColors.bg,
              elevation: 0,
              pinned: true,
              expandedHeight: 240,
              leading: IconButton(
                icon: Icon(Icons.arrow_back_rounded, color: AppColors.text),
                onPressed: () => Get.back(),
              ),
              actions: [
                IconButton(
                  icon: Icon(Icons.bookmark_border_rounded, color: AppColors.text),
                  onPressed: () {},
                ),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: Stack(
                  fit: StackFit.expand,
                  children: [
                    _HeroImage(url: service.heroUrl.isNotEmpty ? service.heroUrl : service.logoUrl),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.black.withOpacity(0.45),
                            Colors.transparent,
                            Colors.black.withOpacity(0.65),
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 18,
                      right: 18,
                      bottom: 16,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          _Logo(url: service.logoUrl),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  service.title,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: AppTextStyles.sectionTitle.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  service.ministry.isEmpty ? "Official Service" : service.ministry,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: AppTextStyles.bodyMuted.copyWith(color: Colors.white.withOpacity(0.85)),
                                ),
                                const SizedBox(height: 8),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    _Pill(text: service.category, bg: Colors.white.withOpacity(0.14), fg: Colors.white),
                                    _Pill(
                                      text: "Official Service",
                                      bg: AppColors.primary.withOpacity(0.22),
                                      fg: Colors.white,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: TabBar(
                    indicator: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    indicatorPadding: const EdgeInsets.all(6),
                    labelColor: AppColors.text,
                    unselectedLabelColor: AppColors.textMuted,
                    labelStyle: const TextStyle(fontWeight: FontWeight.w800),
                    tabs: const [
                      Tab(text: "Overview"),
                      Tab(text: "Process"),
                      Tab(text: "FAQ"),
                    ],
                  ),
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                child: SizedBox(
                  height: 900, // enough space; scroll is handled by outer CustomScrollView
                  child: TabBarView(
                    children: [
                      _OverviewTab(service: service),
                      _ProcessTab(service: service),
                      _FaqTab(service: service),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),

        bottomNavigationBar: SafeArea(
          top: false,
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
            decoration: BoxDecoration(
              color: AppColors.card,
              border: Border(top: BorderSide(color: AppColors.border)),
            ),
            child: Row(
              children: [
                IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.share_outlined, color: AppColors.textMuted),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                    onPressed: service.portalUrl.trim().isEmpty
                        ? null
                        : () {
                      // You can open with url_launcher later.
                      Get.snackbar("Portal Link", service.portalUrl,
                          snackPosition: SnackPosition.BOTTOM);
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.secondary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text("Visit Official Portal", style: TextStyle(fontWeight: FontWeight.w900)),
                        SizedBox(width: 10),
                        Icon(Icons.open_in_new_rounded, size: 18),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/* ----------------------------- Tabs ----------------------------- */

class _OverviewTab extends StatelessWidget {
  const _OverviewTab({required this.service});
  final EServiceModel service;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        _Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(service.subtitle.isEmpty ? "Overview" : service.subtitle, style: AppTextStyles.sectionTitle),
              const SizedBox(height: 10),
              Text(
                (service.overview.isEmpty)
                    ? "This service provides official guidance. Please refer to the portal for updated requirements."
                    : service.overview,
                style: AppTextStyles.body,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        if (service.eligibility.isNotEmpty)
          _Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Eligibility Criteria", style: AppTextStyles.sectionTitle),
                const SizedBox(height: 10),
                ...service.eligibility.map((e) => _Bullet(text: e)).toList(),
              ],
            ),
          ),

        const SizedBox(height: 12),

        if (service.requiredDocs.isNotEmpty)
          _Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Required Documents", style: AppTextStyles.sectionTitle),
                const SizedBox(height: 12),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: service.requiredDocs.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.25,
                  ),
                  itemBuilder: (_, i) => _DocCard(item: service.requiredDocs[i]),
                ),
              ],
            ),
          ),

        const SizedBox(height: 12),

        _Card(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("How to Access", style: AppTextStyles.sectionTitle),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  "~${service.etaMinutes} Mins",
                  style: TextStyle(color: AppColors.accent, fontWeight: FontWeight.w900),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ProcessTab extends StatelessWidget {
  const _ProcessTab({required this.service});
  final EServiceModel service;

  @override
  Widget build(BuildContext context) {
    if (service.processSteps.isEmpty) {
      return ListView(
        padding: EdgeInsets.zero,
        children: [
          _Card(
            child: Text(
              "Process steps not provided yet.\nAdd processSteps from your portal.",
              style: AppTextStyles.bodyMuted,
            ),
          ),
        ],
      );
    }

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        _Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Steps", style: AppTextStyles.sectionTitle),
              const SizedBox(height: 10),
              ...List.generate(service.processSteps.length, (i) {
                final s = service.processSteps[i];
                return _StepRow(index: i + 1, title: s.title, desc: s.description);
              }),
            ],
          ),
        ),
      ],
    );
  }
}

class _FaqTab extends StatelessWidget {
  const _FaqTab({required this.service});
  final EServiceModel service;

  @override
  Widget build(BuildContext context) {
    if (service.faqs.isEmpty) {
      return ListView(
        padding: EdgeInsets.zero,
        children: [
          _Card(
            child: Text(
              "No FAQs yet.\nAdd faqs from your portal.",
              style: AppTextStyles.bodyMuted,
            ),
          ),
        ],
      );
    }

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        _Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Frequently Asked Questions", style: AppTextStyles.sectionTitle),
              const SizedBox(height: 10),
              ...service.faqs.map((f) => _FaqTile(item: f)).toList(),
            ],
          ),
        ),
      ],
    );
  }
}

/* ----------------------------- UI Bits ----------------------------- */

class _HeroImage extends StatelessWidget {
  const _HeroImage({required this.url});
  final String url;

  bool get _has => url.trim().isNotEmpty;

  @override
  Widget build(BuildContext context) {
    if (!_has) {
      return Container(
        color: AppColors.primary.withOpacity(0.15),
        child: const Center(child: Icon(Icons.public_rounded, size: 60, color: Colors.white70)),
      );
    }

    return Image.network(
      url.trim(),
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: AppColors.primary.withOpacity(0.15),
        child: const Center(child: Icon(Icons.public_rounded, size: 60, color: Colors.white70)),
      ),
    );
  }
}

class _Logo extends StatelessWidget {
  const _Logo({required this.url});
  final String url;

  bool get _has => url.trim().isNotEmpty;

  @override
  Widget build(BuildContext context) {
    final box = Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.18),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.22)),
      ),
      child: Icon(Icons.apps_rounded, color: Colors.white.withOpacity(0.9)),
    );

    if (!_has) return box;

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Image.network(
        url.trim(),
        width: 56,
        height: 56,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => box,
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.text, required this.bg, required this.fg});
  final String text;
  final Color bg;
  final Color fg;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withOpacity(0.14)),
      ),
      child: Text(
        text,
        style: TextStyle(color: fg, fontWeight: FontWeight.w900, fontSize: 12),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: child,
    );
  }
}

class _Bullet extends StatelessWidget {
  const _Bullet({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.12),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Icon(Icons.check_rounded, size: 14, color: AppColors.primary),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: AppTextStyles.body)),
        ],
      ),
    );
  }
}

class _DocCard extends StatelessWidget {
  const _DocCard({required this.item});
  final DocItem item;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.10),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(Icons.description_outlined, color: AppColors.accent),
          ),
          const SizedBox(height: 10),
          Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppTextStyles.sectionTitle.copyWith(fontSize: 14)),
          const SizedBox(height: 4),
          Text(item.type, style: AppTextStyles.bodyMuted),
        ],
      ),
    );
  }
}

class _StepRow extends StatelessWidget {
  const _StepRow({required this.index, required this.title, required this.desc});
  final int index;
  final String title;
  final String desc;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Container(
                width: 18,
                height: 18,
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.border),
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
              ),
              Container(width: 2, height: 58, color: AppColors.border),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppTextStyles.sectionTitle.copyWith(fontSize: 14)),
                const SizedBox(height: 4),
                Text(desc, style: AppTextStyles.bodyMuted),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FaqTile extends StatelessWidget {
  const _FaqTile({required this.item});
  final FaqItem item;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.bg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 12),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        title: Text(item.q, style: AppTextStyles.sectionTitle.copyWith(fontSize: 14)),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(item.a, style: AppTextStyles.body),
          ),
        ],
      ),
    );
  }
}