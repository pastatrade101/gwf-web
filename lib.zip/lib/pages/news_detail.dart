import 'package:flutter/material.dart';

import '../core/models/news_model.dart';

class ProShimmer extends StatefulWidget {
  final Widget child;
  final double radius;

  const ProShimmer({super.key, required this.child, this.radius = 16});

  @override
  State<ProShimmer> createState() => _ProShimmerState();
}

class _ProShimmerState extends State<ProShimmer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(widget.radius),
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return Stack(
            fit: StackFit.passthrough,
            children: [
              widget.child,
              Positioned.fill(
                child: ShaderMask(
                  blendMode: BlendMode.srcATop,
                  shaderCallback: (rect) {
                    final t = _c.value;
                    return LinearGradient(
                      begin: Alignment(-1.0 - 0.2 + (t * 2.4), 0),
                      end: Alignment(-0.2 + (t * 2.4), 0),
                      colors: [
                        Colors.white.withOpacity(0.0),
                        Colors.white.withOpacity(0.35),
                        Colors.white.withOpacity(0.0),
                      ],
                      stops: const [0.25, 0.5, 0.75],
                    ).createShader(rect);
                  },
                  child: Container(color: Colors.white),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}


class ProNetworkImage extends StatelessWidget {
  final String? url;
  final double radius;
  final BoxFit fit;

  /// ✅ add placeholder support
  final Widget? placeholder;

  const ProNetworkImage({
    super.key,
    required this.url,
    this.radius = 16,
    this.fit = BoxFit.cover,
    this.placeholder, // ✅ new
  });

  bool get _hasUrl => url != null && url!.trim().isNotEmpty;

  @override
  Widget build(BuildContext context) {
    final fallback = placeholder ??
        Container(
          color: const Color(0xFFEFF2FA),
          child: const Center(
            child: Icon(Icons.image_outlined, color: Colors.black45),
          ),
        );

    if (!_hasUrl) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: fallback,
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Image.network(
        url!.trim(),
        fit: fit,
        loadingBuilder: (context, child, prog) {
          if (prog == null) return child;
          return ProShimmer(
            radius: radius,
            child: Container(color: const Color(0xFFE9ECF6)),
          );
        },
        errorBuilder: (_, __, ___) => fallback,
      ),
    );
  }
}

class NewsDetailPagePro extends StatelessWidget {
  final NewsModel news;

  const NewsDetailPagePro({super.key, required this.news});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final tagColor = Color(news.tagColorValue);

    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            pinned: true,
            stretch: true,
            expandedHeight: 280,
            automaticallyImplyLeading: true,
            leading: _GlassIconButton(
              icon: Icons.arrow_back_rounded,
              onTap: () => Navigator.pop(context),
            ),
            actions: [
              _GlassIconButton(
                icon: Icons.share_rounded,
                onTap: () {
                  // add share later if you want
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Share coming soon")),
                  );
                },
              ),
              const SizedBox(width: 10),
            ],
            flexibleSpace: FlexibleSpaceBar(
              stretchModes: const [
                StretchMode.zoomBackground,
                StretchMode.blurBackground,
              ],
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Hero image
                  ProNetworkImage(
                    url: news.imageUrl,
                    fit: BoxFit.cover,
                    placeholder: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF0B0F1A), Color(0xFF0E2B3D)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: const Center(
                        child: Icon(Icons.newspaper_rounded,
                            color: Colors.white70, size: 62),
                      ),
                    ),
                  ),
                  // Dark gradient overlay for text legibility
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.black.withOpacity(0.55),
                          Colors.transparent,
                          Colors.black.withOpacity(0.72),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                  // Bottom meta (title + chips)
                  Positioned(
                    left: 18,
                    right: 18,
                    bottom: 18,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          children: [
                            _Pill(
                              text: news.categoryLabel,
                              bg: Colors.white.withOpacity(0.14),
                              fg: Colors.white,
                              border: Colors.white.withOpacity(0.22),
                            ),
                            _Pill(
                              text: news.tag,
                              bg: tagColor.withOpacity(0.18),
                              fg: tagColor,
                              border: tagColor.withOpacity(0.35),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text(
                          news.title,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.headlineSmall?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            height: 1.15,
                            letterSpacing: -0.3,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _dateText(news.publishedAt),
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: Colors.white.withOpacity(0.85),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Content
          SliverToBoxAdapter(
            child: Container(
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 20),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 24,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if ((news.snippet).trim().isNotEmpty) ...[
                    Text(
                      news.snippet,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Divider(color: Colors.black.withOpacity(0.08)),
                    const SizedBox(height: 14),
                  ],

                  // If you have a full content field later, use it here.
                  // For now we show a "body" built from snippet + optional link/source.
                  Text(
                    _buildBody(news),
                    style: theme.textTheme.bodyLarge?.copyWith(
                      height: 1.55,
                      color: const Color(0xFF101423),
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  const SizedBox(height: 18),

                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      if (news.source != null && news.source!.trim().isNotEmpty)
                        _MetaChip(icon: Icons.apartment_rounded, text: news.source!),
                      if (news.author != null && news.author!.trim().isNotEmpty)
                        _MetaChip(icon: Icons.person_rounded, text: news.author!),
                      if (news.link != null && news.link!.trim().isNotEmpty)
                        _MetaChip(icon: Icons.link_rounded, text: "Open link"),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 18)),
        ],
      ),
    );
  }

  static String _buildBody(NewsModel n) {
    // If later you add `content` field in model, replace this.
    // For now, show a clean readable body.
    final b = StringBuffer();
    b.writeln(n.snippet.trim());
    b.writeln();
    b.writeln(
        "This update is provided under ${n.categoryLabel}. Please check official sources for any new changes.");
    if (n.link != null && n.link!.trim().isNotEmpty) {
      b.writeln();
      b.writeln("More info: ${n.link}");
    }
    return b.toString().trim();
  }

  static String _dateText(DateTime? dt) {
    if (dt == null) return "—";
    final mm = dt.month.toString().padLeft(2, '0');
    final dd = dt.day.toString().padLeft(2, '0');
    return "${dt.year}-$mm-$dd";
  }
}

class _GlassIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _GlassIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: onTap,
          child: Ink(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.25),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: Colors.white.withOpacity(0.18)),
            ),
            child: Icon(icon, color: Colors.white),
          ),
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;
  final Color border;

  const _Pill({
    required this.text,
    required this.bg,
    required this.fg,
    required this.border,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: border),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: fg,
          fontWeight: FontWeight.w800,
          fontSize: 12,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final IconData icon;
  final String text;

  const _MetaChip({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F5FB),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE6E8F0)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: Colors.black.withOpacity(0.65)),
          const SizedBox(width: 8),
          Text(
            text,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}