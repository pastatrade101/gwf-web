import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/models/banner_model.dart';


class BannerService {
  // ✅ DEFINE THESE (you are missing them)
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  static const String _collection = 'banners';

  Stream<List<BannerModel>> streamActiveBanners({int limit = 10}) {
    final q = _db
        .collection(_collection)
        .where('isActive', isEqualTo: true)
        .limit(limit);

    return q.snapshots().map((snap) {
      final list = snap.docs
          .map((d) => BannerModel.fromMap(d.data(), d.id)) // ✅ correct
          .where((b) => b.imageUrl.isNotEmpty)
          .toList();

      // Highest priority first
      list.sort((a, b) => b.priority.compareTo(a.priority));
      return list;
    });
  }
}