import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';

class ServicesListPage extends StatelessWidget {
  const ServicesListPage({
    super.key,
    required this.title,
  });

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: Text(title, style: AppTextStyles.appBar),
        centerTitle: true,
        backgroundColor: AppColors.bg,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
        children: [
          _SearchBox(),
          const SizedBox(height: 12),
          _ChipRow(),
          const SizedBox(height: 14),
          Text("AVAILABLE SERVICES", style: AppTextStyles.mutedCaps),
          const SizedBox(height: 10),
          ..._tiles(),
        ],
      ),
    );
  }

  List<Widget> _tiles() {
    final items = [
      ("National Vaccination Program", "Ministry of Health", Icons.vaccines),
      ("Maternal Care Grant", "Ministry of Social Development", Icons.emoji_emotions),
      ("Public Hospital Registration", "Ministry of Health", Icons.local_hospital),
      ("Senior Citizen Card", "Dept. of Elder Affairs", Icons.elderly),
      ("Mental Health Support", "National Wellness Center", Icons.health_and_safety),
      ("Emergency Ambulance Svc", "Emergency Response Unit", Icons.emergency),
    ];

    return items.map((e) => _ServiceTile(
      title: e.$1,
      subtitle: e.$2,
      icon: e.$3,
    )).toList();
  }
}

class _SearchBox extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          const Icon(Icons.search, color: AppColors.textMuted),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search services...",
                hintStyle: AppTextStyles.bodyMuted,
                border: InputBorder.none,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChipRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final chips = ["All", "Hospitals", "Grants", "Insurance"];
    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: chips.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) {
          final active = i == 0;
          return ChoiceChip(
            label: Text(chips[i]),
            selected: active,
            showCheckmark: false,
            selectedColor: AppColors.secondary,
            backgroundColor: Colors.white,
            labelStyle: active
                ? AppTextStyles.chipActive
                : AppTextStyles.chip,
            shape: StadiumBorder(
              side: BorderSide(color: active ? Colors.transparent : AppColors.border),
            ),
            onSelected: (_) {},
          );
        },
      ),
    );
  }
}

class _ServiceTile extends StatelessWidget {
  const _ServiceTile({
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: AppColors.secondary.withOpacity(0.10),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: AppColors.secondary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppTextStyles.tileTitle),
                const SizedBox(height: 2),
                Text(subtitle, style: AppTextStyles.bodyMuted),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
        ],
      ),
    );
  }
}