import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/models/e_service_model.dart';


class EServiceFirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final String _col = "e_services";

  Stream<List<EServiceModel>> streamActive({int limit = 50}) {
    final q = _db
        .collection(_col)
        .where("isActive", isEqualTo: true)
        .orderBy("priority", descending: true)
        .limit(limit);

    return q.snapshots().map((snap) {
      final list = snap.docs
          .map((d) => EServiceModel.fromMap(d.data(), d.id))
      // ensure logo exists
          .where((s) => s.logoUrl.trim().isNotEmpty)
          .toList();
      return list;
    });
  }
}