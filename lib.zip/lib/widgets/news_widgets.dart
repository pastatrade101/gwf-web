import 'dart:async';
import 'package:flutter/material.dart';
import '../core/models/news_model.dart';

/// ----------------------- Helpers: date text -----------------------
String newsTimeText(DateTime? dt) {
  if (dt == null) return "—";
  final now = DateTime.now();
  final d = DateTime(dt.year, dt.month, dt.day);
  final n = DateTime(now.year, now.month, now.day);
  final diff = n.difference(d).inDays;

  if (diff == 0) return "Today";
  if (diff == 1) return "Yesterday";
  if (diff < 7) return "$diff days ago";

  final mm = dt.month.toString().padLeft(2, '0');
  final dd = dt.day.toString().padLeft(2, '0');
  return "${dt.year}-$mm-$dd";
}

/// ------------------------------------------------------------
/// HomePageAnimation (your exact class)
/// ------------------------------------------------------------
class HomePageAnimation extends StatefulWidget {
  final Widget child;
  const HomePageAnimation({super.key, required this.child});

  @override
  State<HomePageAnimation> createState() => _HomePageAnimationState();
}

class _HomePageAnimationState extends State<HomePageAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(opacity: _fade, child: SlideTransition(position: _slide, child: widget.child));
  }
}

/// ------------------------------------------------------------
/// ProStagger
/// ------------------------------------------------------------
class ProStagger extends StatefulWidget {
  final Widget child;
  final int delayMs;
  const ProStagger({super.key, required this.child, this.delayMs = 0});

  @override
  State<ProStagger> createState() => _ProStaggerState();
}

class _ProStaggerState extends State<ProStagger> {
  bool _show = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(Duration(milliseconds: widget.delayMs), () {
      if (mounted) setState(() => _show = true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 350),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeIn,
      transitionBuilder: (child, anim) {
        final fade = CurvedAnimation(parent: anim, curve: Curves.easeOut);
        final slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(
          CurvedAnimation(parent: anim, curve: Curves.easeOutCubic),
        );
        return FadeTransition(opacity: fade, child: SlideTransition(position: slide, child: child));
      },
      child: _show ? widget.child : const SizedBox.shrink(),
    );
  }
}

/// ------------------------------------------------------------
/// ProShimmer
/// ------------------------------------------------------------
class ProShimmer extends StatefulWidget {
  final Widget child;
  final double borderRadius;
  const ProShimmer({super.key, required this.child, this.borderRadius = 14});

  @override
  State<ProShimmer> createState() => _ProShimmerState();
}

class _ProShimmerState extends State<ProShimmer> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(widget.borderRadius),
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return Stack(
            fit: StackFit.passthrough,
            children: [
              widget.child,
              Positioned.fill(
                child: ShaderMask(
                  blendMode: BlendMode.srcATop,
                  shaderCallback: (rect) {
                    final t = _c.value;
                    return LinearGradient(
                      begin: Alignment(-1.0 - 0.2 + (t * 2.4), 0),
                      end: Alignment(-0.2 + (t * 2.4), 0),
                      colors: [
                        Colors.white.withOpacity(0.0),
                        Colors.white.withOpacity(0.35),
                        Colors.white.withOpacity(0.0),
                      ],
                      stops: const [0.25, 0.5, 0.75],
                    ).createShader(rect);
                  },
                  child: Container(color: Colors.white),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// ------------------------------------------------------------
/// ProNetworkImage
/// ------------------------------------------------------------
class ProNetworkImage extends StatelessWidget {
  const ProNetworkImage({
    super.key,
    required this.url,
    this.borderRadius = 0,
    this.fit = BoxFit.cover,
    this.placeholder,
  });

  final String? url;
  final double borderRadius;
  final BoxFit fit;
  final Widget? placeholder;

  bool get _hasUrl => url != null && url!.trim().isNotEmpty;

  @override
  Widget build(BuildContext context) {
    final ph = placeholder ??
        Container(
          color: const Color(0xFFEFF2FA),
          child: const Center(child: Icon(Icons.image_outlined, color: Colors.black45)),
        );

    if (!_hasUrl) {
      return ClipRRect(borderRadius: BorderRadius.circular(borderRadius), child: ph);
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: Image.network(
        url!.trim(),
        fit: fit,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return ProShimmer(borderRadius: borderRadius, child: Container(color: const Color(0xFFE9ECF6)));
        },
        errorBuilder: (_, __, ___) => ph,
      ),
    );
  }
}

/// ------------------------------------------------------------
/// Shimmer page skeleton
/// ------------------------------------------------------------
class NewsShimmer extends StatelessWidget {
  const NewsShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 18),
      children: const [
        ProShimmer(borderRadius: 12, child: _ShimmerBox(height: 34, widthFactor: 0.55)),
        SizedBox(height: 14),
        ProShimmer(borderRadius: 14, child: _ShimmerBox(height: 52)),
        SizedBox(height: 16),
        ProShimmer(borderRadius: 999, child: _ShimmerRowChips()),
        SizedBox(height: 16),
        ProShimmer(borderRadius: 18, child: _ShimmerBox(height: 300)),
        SizedBox(height: 18),
        ProShimmer(borderRadius: 12, child: _ShimmerBox(height: 26, widthFactor: 0.45)),
        SizedBox(height: 10),
        ProShimmer(borderRadius: 16, child: _ShimmerTile()),
        SizedBox(height: 12),
        ProShimmer(borderRadius: 16, child: _ShimmerTile()),
        SizedBox(height: 12),
        ProShimmer(borderRadius: 16, child: _ShimmerTile()),
      ],
    );
  }
}

class _ShimmerBox extends StatelessWidget {
  const _ShimmerBox({required this.height, this.widthFactor = 1});
  final double height;
  final double widthFactor;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: FractionallySizedBox(
        widthFactor: widthFactor,
        child: Container(
          height: height,
          decoration: BoxDecoration(color: const Color(0xFFE9ECF6), borderRadius: BorderRadius.circular(14)),
        ),
      ),
    );
  }
}

class _ShimmerRowChips extends StatelessWidget {
  const _ShimmerRowChips();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: Row(
        children: [
          Expanded(child: _pill()),
          SizedBox(width: 10),
          Expanded(child: _pill()),
          SizedBox(width: 10),
          Expanded(child: _pill()),
        ],
      ),
    );
  }

  Widget _pill() => Container(decoration: BoxDecoration(color: const Color(0xFFE9ECF6), borderRadius: BorderRadius.circular(999)));
}

class _ShimmerTile extends StatelessWidget {
  const _ShimmerTile();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFE9ECF6), borderRadius: BorderRadius.circular(16)),
      child: Row(
        children: [
          Container(
            width: 62,
            height: 62,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.6), borderRadius: BorderRadius.circular(14)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(height: 12, width: 120, color: Colors.white54),
              const SizedBox(height: 10),
              Container(height: 14, width: double.infinity, color: Colors.white54),
              const SizedBox(height: 8),
              Container(height: 12, width: double.infinity, color: Colors.white54),
            ]),
          ),
        ],
      ),
    );
  }
}

/// ------------------------------------------------------------
/// Search box
/// ------------------------------------------------------------
class NewsSearchBox extends StatelessWidget {
  const NewsSearchBox({super.key, required this.controller, required this.onChanged});

  final TextEditingController controller;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 16, offset: const Offset(0, 6))],
      ),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        decoration: const InputDecoration(
          hintText: "Search updates...",
          prefixIcon: Icon(Icons.search_rounded),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        ),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// Featured card
/// ------------------------------------------------------------
class FeaturedCard extends StatelessWidget {
  const FeaturedCard({super.key, required this.item, required this.onReadFull});

  final NewsModel item;
  final VoidCallback onReadFull;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final fallbackHero = Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF0B0F1A), Color(0xFF0E2B3D)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: const Center(child: Icon(Icons.badge_outlined, size: 54, color: Colors.white70)),
    );

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 22, offset: const Offset(0, 10))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Stack(children: [
          SizedBox(
            height: 170,
            width: double.infinity,
            child: ProNetworkImage(url: item.imageUrl, fit: BoxFit.cover, placeholder: fallbackHero),
          ),
          Positioned(
            left: 14,
            top: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.45),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white.withOpacity(0.18)),
              ),
              child: const Text(
                "FEATURED",
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 0.6, fontSize: 12),
              ),
            ),
          ),
        ]),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(
                item.categoryLabel.toUpperCase(),
                style: theme.textTheme.labelLarge?.copyWith(
                  color: const Color(0xFF2F6BFF),
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.6,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                "•  ${newsTimeText(item.publishedAt)}",
                style: theme.textTheme.labelLarge?.copyWith(
                  color: Colors.black.withOpacity(0.45),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ]),
            const SizedBox(height: 8),
            Text(item.title, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900, height: 1.2)),
            const SizedBox(height: 10),
            Text(
              item.snippet,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: Colors.black.withOpacity(0.55),
                height: 1.4,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: onReadFull,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFE9ECF6),
                  foregroundColor: const Color(0xFF2F6BFF),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text("Read Full Story", style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}

/// ------------------------------------------------------------
/// Recent tile
/// ------------------------------------------------------------
class RecentTile extends StatelessWidget {
  const RecentTile({super.key, required this.item, required this.onTap});

  final NewsModel item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final tagColor = Color(item.tagColorValue);

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            SizedBox(
              width: 62,
              height: 62,
              child: ProNetworkImage(url: item.imageUrl, borderRadius: 14, fit: BoxFit.cover),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(color: tagColor.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                    child: Text(
                      item.tag,
                      style: TextStyle(color: tagColor, fontWeight: FontWeight.w900, letterSpacing: 0.4, fontSize: 12),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    newsTimeText(item.publishedAt),
                    style: theme.textTheme.labelLarge?.copyWith(
                      color: Colors.black.withOpacity(0.45),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                Text(
                  item.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  item.snippet,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.black.withOpacity(0.55),
                    height: 1.35,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ]),
            ),
            const SizedBox(width: 8),
            Icon(Icons.chevron_right_rounded, color: Colors.black.withOpacity(0.35)),
          ]),
        ),
      ),
    );
  }
}