
class Council {
  final String name;
  final String website;

  Council({required this.name, required this.website});
}
