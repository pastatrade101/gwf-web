import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import 'home_controller.dart';
import 'widgets/banner_slider.dart';
import 'widgets/banner_slider_shimmer.dart';
import 'widgets/home_search_bar.dart';
import 'widgets/sector_grid.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Put controller once (safe)
  final HomeController c = Get.put(HomeController(), permanent: true);

  late final TextEditingController searchCtrl;

  @override
  void initState() {
    super.initState();
    searchCtrl = TextEditingController();
  }

  @override
  void dispose() {
    searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg,
        elevation: 0,
        centerTitle: true,
        leading: Navigator.of(context).canPop()
            ? IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          color: AppColors.textPrimary,
          onPressed: () => Navigator.maybePop(context),
        )
            : null,
        title: Text(
          "Service Categories",
          style: AppTextStyles.appBar,
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
          children: [
            HomeSearchBar(
              controller: searchCtrl,
              onChanged: c.onSearchChanged, // debounced in controller
            ),
            const SizedBox(height: 14),

            // ✅ Slider section (only this part reacts, not whole page)
            Obx(() {
              if (c.isBannerLoading.value) return const BannerSliderShimmer();

              final err = c.bannerError.value;
              if (err != null && err.toString().trim().isNotEmpty) {
                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.error.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.error.withOpacity(0.2)),
                  ),
                  child: Text(
                    "Banner error:\n$err",
                    style: const TextStyle(
                      color: AppColors.error,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                );
              }

              if (c.banners.isEmpty) return const SizedBox.shrink();

              return BannerSlider(
                banners: c.banners,
                height: 150,
              );
            }),

            const SizedBox(height: 18),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Browse by Sector", style: AppTextStyles.sectionTitle),
                Text("View All", style: AppTextStyles.link),
              ],
            ),
            const SizedBox(height: 14),

            const SectorGrid(),
          ],
        ),
      ),
    );
  }
}