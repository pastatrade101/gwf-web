import 'package:flutter/material.dart';


import '../../../core/constants/app_colors.dart';
import '../../../core/utils/shimmer.dart';

class BannerSliderShimmer extends StatelessWidget {
  final double height;

  const BannerSliderShimmer({
    super.key,
    this.height = 160,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ProShimmer(
            radius: 18,
            child: Container(
              height: height,
              decoration: BoxDecoration(
                color: AppColors.border.withOpacity(0.5),
                borderRadius: BorderRadius.circular(18),
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            3,
                (_) => Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              height: 6,
              width: 10,
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.25),
                borderRadius: BorderRadius.circular(99),
              ),
            ),
          ),
        ),
      ],
    );
  }
}