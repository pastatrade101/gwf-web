import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_text_styles.dart';

class SectorGrid extends StatelessWidget {
  const SectorGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final items = const [
      _SectorItem("Healthcare", "Hospitals, Clinics,\nMental Health", Icons.medical_services_rounded),
      _SectorItem("Education", "Schools, Grants,\nUniversities", Icons.school_rounded),
      _SectorItem("Public Safety", "Police, Fire,\nEmergency", Icons.shield_rounded),
      _SectorItem("Transport", "Licenses, Transit,\nRoad Services", Icons.directions_bus_rounded),
      _SectorItem("Social Services", "Housing, Employment,\nBenefits", Icons.groups_rounded),
      _SectorItem("Legal & ID", "Passports, ID Cards,\nCertificates", Icons.fingerprint_rounded),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 1.18, // ✅ FIX: more vertical room
      ),
      itemBuilder: (_, i) => _SectorCard(item: items[i]),
    );
  }
}

class _SectorItem {
  final String title;
  final String subtitle;
  final IconData icon;

  const _SectorItem(this.title, this.subtitle, this.icon);
}

class _SectorCard extends StatelessWidget {
  final _SectorItem item;
  const _SectorCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.card,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          // TODO: navigate to sector page
        },
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Icon
              Container(
                height: 44,
                width: 44,
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(item.icon, color: AppColors.accent, size: 22),
              ),

              const SizedBox(height: 10),

              // Title (max 1–2 lines)
              Text(
                item.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyles.sectionTitle,
              ),

              const SizedBox(height: 6),

              // ✅ FIX: Flexible subtitle
              Expanded(
                child: Text(
                  item.subtitle,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.bodyMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}