import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../constants/app_colors.dart';

class AppTheme {
  static ThemeData light = ThemeData(
    brightness: Brightness.light,
    primaryColor: AppColors.primary,
    scaffoldBackgroundColor: AppColors.bg,
    cardColor: AppColors.card,

    textTheme: const TextTheme(
      headlineLarge: TextStyle(
        color: AppColors.textPrimary,
        fontWeight: FontWeight.w900,
      ),
      bodyMedium: TextStyle(
        color: AppColors.textSecondary,
        fontWeight: FontWeight.w600,
      ),
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.bg,
      elevation: 0,
      foregroundColor: AppColors.textPrimary,
    ),
  );

  static ThemeData dark = ThemeData(
    brightness: Brightness.dark,
    primaryColor: AppColors.primary,
    scaffoldBackgroundColor: Colors.black,

    textTheme: const TextTheme(
      headlineLarge: TextStyle(
        color: AppColors.textPrimaryDark,
        fontWeight: FontWeight.w900,
      ),
      bodyMedium: TextStyle(
        color: AppColors.textSecondaryDark,
        fontWeight: FontWeight.w600,
      ),
    ),
  );
}