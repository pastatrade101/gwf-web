import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

class AppTextStyles {
  AppTextStyles._();

  static final TextStyle appBar = GoogleFonts.nunito(
    fontSize: 18,
    fontWeight: FontWeight.w800,
    color: AppColors.textPrimary,
  );

  static final TextStyle headline = GoogleFonts.nunito(
    fontSize: 26,
    fontWeight: FontWeight.w900,
    color: AppColors.textPrimary,
    letterSpacing: -0.4,
  );

  static final TextStyle sectionTitle = GoogleFonts.nunito(
    fontSize: 18,
    fontWeight: FontWeight.w800,
    color: AppColors.textPrimary,
  );

  static final TextStyle body = GoogleFonts.nunito(
    fontSize: 14,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
    height: 1.45,
  );

  static final TextStyle bodyMuted = GoogleFonts.nunito(
    fontSize: 13,
    fontWeight: FontWeight.w600,
    color: AppColors.textMuted,
  );

  static final TextStyle link = GoogleFonts.nunito(
    fontSize: 14,
    fontWeight: FontWeight.w800,
    color: AppColors.secondary,
  );

  static final TextStyle tileTitle = GoogleFonts.nunito(
    fontSize: 15,
    fontWeight: FontWeight.w900,
    color: AppColors.textPrimary,
  );

  static final TextStyle mutedCaps = GoogleFonts.nunito(
    fontSize: 12,
    fontWeight: FontWeight.w900,
    color: AppColors.textMuted,
    letterSpacing: 1.0,
  );

  static final TextStyle chip = GoogleFonts.nunito(
    fontSize: 13,
    fontWeight: FontWeight.w800,
    color: AppColors.textPrimary,
  );

  static final TextStyle chipActive = GoogleFonts.nunito(
    fontSize: 13,
    fontWeight: FontWeight.w900,
    color: Colors.white,
  );

  static final TextTheme textTheme = GoogleFonts.nunitoTextTheme().copyWith(
    headlineMedium: headline,
    titleLarge: sectionTitle,
    bodyLarge: body,
    bodyMedium: body,
    bodySmall: bodyMuted,
    labelLarge: link,
  );
}