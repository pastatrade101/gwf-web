import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // ===============================
  // BRAND
  // ===============================
  static const Color primary = Color(0xFF008751);
  static const Color secondary = Color(0xFF2F6BFF);
  static const Color accent = secondary;

  // ===============================
  // BACKGROUNDS
  // ===============================
  static const Color bg = Color(0xFFF6F7FB);
  static const Color bgDark = Color(0xFF0B0F1A);

  // ===============================
  // CARDS
  // ===============================
  static const Color card = Color(0xFFFFFFFF);
  static const Color cardDark = Color(0xFF121826);

  // ===============================
  // BORDERS
  // ===============================
  static const Color border = Color(0xFFE6E8F0);
  static const Color borderDark = Color(0xFF2A2F3A);

  // ===============================
  // TEXT — LIGHT MODE
  // ===============================
  static const Color textPrimary = Color(0xFF0D0F12);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textMuted = Color(0xFF9CA3AF);

  // ===============================
  // TEXT — DARK MODE
  // ===============================
  static const Color textPrimaryDark = Color(0xFFE5E7EB);
  static const Color textSecondaryDark = Color(0xFF9CA3AF);
  static const Color textMutedDark = Color(0xFF9AA4B2);

  // ===============================
  // STATUS
  // ===============================
  static const Color error = Color(0xFFDC2626);
  static const Color success = Color(0xFF16A34A);
  static const Color warning = Color(0xFFF59E0B);

  // ===============================
  // BACKWARD-COMPATIBILITY ALIASES
  // (prevents breaking older widgets)
  // ===============================
  static const Color text = textPrimary;
  static const Color textDark = textPrimaryDark;
}