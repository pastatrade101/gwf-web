import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/models/e_service_model.dart';
import '../../services/e_service_firestore_service.dart';

class EServicesController extends GetxController {
  final service = EServiceFirestoreService();

  final searchCtrl = TextEditingController();

  final RxBool isLoading = true.obs;
  // ✅ correct
  final RxnString error = RxnString();

  final RxString activeChip = "All".obs;
  final RxString query = "".obs;

  final RxList<EServiceModel> all = <EServiceModel>[].obs;

  Timer? _debounce;
  StreamSubscription? _sub;

  List<String> get chips {
    // derived from data + "All"
    final set = <String>{"All"};
    for (final s in all) {
      final c = s.category.trim();
      if (c.isNotEmpty) set.add(c);
    }
    return set.toList();
  }

  @override
  void onInit() {
    super.onInit();
    _sub = service.streamActive().listen((list) {
      all.assignAll(list);
      isLoading.value = false;
      error?.value = null;
    }, onError: (e) {
      isLoading.value = false;
      error?.value = e.toString();
    });
  }

  void onSearchChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 320), () {
      query.value = v.trim();
    });
  }

  void setChip(String v) => activeChip.value = v;

  List<EServiceModel> get filtered {
    final q = query.value.toLowerCase();
    final cat = activeChip.value;

    return all.where((s) {
      final catOk = (cat == "All") || (s.category == cat);
      if (!catOk) return false;
      if (q.isEmpty) return true;

      return s.title.toLowerCase().contains(q) ||
          s.subtitle.toLowerCase().contains(q) ||
          s.ministry.toLowerCase().contains(q);
    }).toList();
  }

  @override
  void onClose() {
    _debounce?.cancel();
    _sub?.cancel();
    searchCtrl.dispose();
    super.onClose();
  }
}