import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import '../core/models/news_model.dart';
import '../services/news_services.dart';

class NewsController extends GetxController {
  NewsController({NewsService? service}) : _service = service ?? NewsService();

  final NewsService _service;

  final tabs = const ["All", "Education", "Health", "Transport"];

  final RxInt activeTab = 0.obs;
  final RxString searchQuery = "".obs;

  final RxBool loading = true.obs;
  final RxString error = "".obs;

  final RxList<NewsModel> allNews = <NewsModel>[].obs;

  StreamSubscription<List<NewsModel>>? _sub;
  Timer? _debounce;

  @override
  void onInit() {
    super.onInit();
    _listenNews();
  }

  void _listenNews() {
    loading.value = true;
    error.value = "";

    _sub?.cancel();
    _sub = _service.streamPublishedNews().listen(
          (items) {
        allNews.assignAll(items);
        loading.value = false;
        error.value = "";
      },
      onError: (e) {
        loading.value = false;
        error.value = e.toString();
      },
    );
  }

  void setTab(int index) {
    activeTab.value = index;
  }

  /// ✅ Debounced search (no rebuild per letter except the list section)
  void onSearchChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      searchQuery.value = value.trim();
    });
  }

  String get selectedTab => tabs[activeTab.value];

  /// ✅ Filtered list (reactive)
  List<NewsModel> get filtered {
    final tab = selectedTab;
    final q = searchQuery.value;

    final list = allNews.where((n) {
      final matchesTab = tab == "All" || n.tabCategory == tab;
      final matchesSearch = n.matchesQuery(q);
      return matchesTab && matchesSearch;
    }).toList()
      ..sort((a, b) => a.compareByDateDesc(b));

    return list;
  }

  NewsModel? get featured {
    final list = filtered.where((e) => e.isFeatured).toList();
    return list.isEmpty ? null : list.first;
  }

  /// ✅ You said: recent updates should include featured too
  List<NewsModel> get recent => List<NewsModel>.from(filtered);

  @override
  void onClose() {
    _debounce?.cancel();
    _sub?.cancel();
    super.onClose();
  }
}


class NewsService {
  NewsService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  /// Collection name in Firestore
  static const String _collection = 'news';

  /// Stream only published news (recommended for mobile app users)
  ///
  /// Firestore fields expected (recommended):
  /// - status: "published"
  /// - publishedAt: Timestamp
  /// - isFeatured: bool
  /// - tabCategory: "All" | "Education" | "Health" | "Transport"
  /// - title, snippet, imageUrl, etc...
  Stream<List<NewsModel>> streamPublishedNews({
    int limit = 100,
  }) {
    final query = _db
        .collection(_collection)
        .where('status', isEqualTo: 'published')
        .orderBy('publishedAt', descending: true)
        .limit(limit);

    return query.snapshots().map((snap) {
      return snap.docs.map((doc) {
        final data = doc.data();
        return NewsModel.fromMap(data, id: doc.id);
      }).toList();
    });
  }

  /// Stream all news (admin usage / debugging)
  Stream<List<NewsModel>> streamAllNews({
    int limit = 200,
  }) {
    final query = _db
        .collection(_collection)
        .orderBy('publishedAt', descending: true)
        .limit(limit);

    return query.snapshots().map((snap) {
      return snap.docs.map((doc) {
        return NewsModel.fromMap(doc.data(), id: doc.id);
      }).toList();
    });
  }

  /// Optional: Fetch once (non-stream)
  Future<List<NewsModel>> fetchPublishedNewsOnce({
    int limit = 50,
  }) async {
    final query = await _db
        .collection(_collection)
        .where('status', isEqualTo: 'published')
        .orderBy('publishedAt', descending: true)
        .limit(limit)
        .get();

    return query.docs.map((doc) {
      return NewsModel.fromMap(doc.data(), id: doc.id);
    }).toList();
  }

  /// Optional: Create/Update a news doc (useful for testing)
  Future<void> upsertNews(NewsModel news) async {
    await _db.collection(_collection).doc(news.id).set(
      _sanitizeForFirestore(news.toMap()),
      SetOptions(merge: true),
    );
  }

  /// Convert DateTime to Timestamp for Firestore if needed
  Map<String, dynamic> _sanitizeForFirestore(Map<String, dynamic> map) {
    final out = Map<String, dynamic>.from(map);

    final dt = out['publishedAt'];
    if (dt is DateTime) {
      out['publishedAt'] = Timestamp.fromDate(dt);
    }

    // remove nulls to keep Firestore clean
    out.removeWhere((key, value) => value == null);
    return out;
  }
}