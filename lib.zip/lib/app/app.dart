import 'package:flutter/material.dart';

import '../features/councils/council_landsales.dart';
import '../features/home/home_screen.dart';
import '../pages/e_service_page.dart';
import '../pages/help_screen.dart';
import '../pages/page_1.dart';
import '../pages/latest_news_page_pro.dart';
import '../shared_components/bottom_nav.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomeScreen(),
      EServicesPage(),
      LatestNewsPagePro(), // ✅ not const
      const HelpScreen(),
      LandSalePage() ,
    ];

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: pages,
      ),
      bottomNavigationBar: MainBottomNav(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
      ),
    );
  }
}