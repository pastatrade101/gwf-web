import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../core/constants/app_theme.dart';

class ThemeController extends GetxController {
  final RxBool isDark = false.obs;

  ThemeMode get themeMode => isDark.value ? ThemeMode.dark : ThemeMode.light;

  ThemeData get lightTheme => AppTheme.light;
  ThemeData get darkTheme => AppTheme.dark;

  void toggleTheme() => isDark.toggle();
}